export class CommonDt {

    // get country data==============//
    id: number;
    iso3: string;
    phonecode: string;
    iso: string;
    country_name: string;
    // end of country data==========//

}
