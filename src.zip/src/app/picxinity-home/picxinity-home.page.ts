import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-picxinity-home',
  templateUrl: './picxinity-home.page.html',
  styleUrls: ['./picxinity-home.page.scss'],
})
export class PicxinityHomePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
