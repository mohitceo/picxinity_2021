import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complete-info',
  templateUrl: './complete-info.page.html',
  styleUrls: ['./complete-info.page.scss'],
})
export class CompleteInfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
